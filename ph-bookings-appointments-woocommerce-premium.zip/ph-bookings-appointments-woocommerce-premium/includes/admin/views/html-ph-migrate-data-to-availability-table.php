<!DOCTYPE html>
<html>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        #regForm {
            background-color: #ffffff;
            margin: 100px auto;
            padding: 40px;
            width: 70%;
            min-width: 300px;
        }

        h1 {
            text-align: center;
        }

        input {
            padding: 10px;
            width: 100%;
            font-size: 17px;
            border: 1px solid #aaaaaa;
        }

        /* Mark input boxes that gets an error on validation: */
        input.invalid {
            background-color: #ffdddd;
        }

        /* Hide all steps by default: */
        .tab {
            display: none;
        }

        button {
            background-color: #1f3368;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 17px;
            cursor: pointer;
        }

        button:hover {
            opacity: 0.8;
        }

        #prevBtn {
            background-color: #bbbbbb;
        }

        /* Make circles that indicate the steps of the form: */
        .step {
            height: 15px;
            width: 15px;
            margin: 0 2px;
            background-color: #bbbbbb;
            border: none;
            border-radius: 50%;
            display: inline-block;
            opacity: 0.5;
        }

        .step.active {
            opacity: 1;
        }

        /* Mark the steps that are finished and valid: */
        .step.finish {
            background-color: #04AA6D;
        }

        th{
            padding: 10px;
        }

        button#nextBtn.disabled {
            opacity: 0.5;
            pointer-events: none;
            cursor: not-allowed;
        }

        .env-fixed{
            color: green;
            font-weight: bold;
        }

        .env-not-fixed{
            color: red;
            font-weight: bold;
        }

        .alert {
            position: relative;
            padding: 0.75rem 1.25rem;
            margin-bottom: 1rem;
            border: 1px solid transparent;
            border-radius: 0.25rem;
        }
        
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
    </style>
<body>
    <?php
        if(isset($_REQUEST['ph_migration_instructions_read']) && !empty($_REQUEST['ph_migration_instructions_read'])){
            update_option('ph_migration_instructions_read_v3_0_0', $_REQUEST['ph_migration_instructions_read']);
        }

        if(isset($_REQUEST['ph_migration_final_consent']) && !empty($_REQUEST['ph_migration_final_consent'])){
            update_option('ph_migration_final_consent_v3_0_0', $_REQUEST['ph_migration_final_consent']);
            
            if($_REQUEST['ph_migration_final_consent'] == 'yes')
            {
                $migration = array(
                    'migration_consent'     => 'no',                    //yes or no	- default no
                    'started'				=> 'no',					//yes or no	- default no
                    'fetched_data'			=> 'no',					//yes or no	- default no
                    'table_prepared'		=> 'no',					//yes or no	- default no
                    'completed' 			=> 'no',					//yes or no - default no
                    'partial'				=> 'no',					//yes or no - default no
                    'order_ids'				=> array(),
                    'order_ids_left' 		=> array(),
                    'order_ids_migrated' 	=> array()
                );
                $option_name    = 'ph_migrate_availability_data_v3_0_0';
                $migration      = get_option($option_name, $migration);
                if(!(isset($migration['migration_consent']) && $migration['migration_consent'] == 'yes'))
                {
                    $migration['migration_consent'] = 'yes';
                    update_option($option_name, $migration);
                }
            }
        }

        // Plugins to be updated
        $fixed_plugins = array(
            array(
                'name' => 'WooCommerce Recurring Bookings and Appointments',
                'version' => '1.1.8',
                'link' => 'https://www.pluginhive.com/product/woocommerce-recurring-bookings-and-appointments/'
            ),
            array(
                'name' => 'Pluginhive Multiple Non-Adjacent Bookings Addon',
                'version' => '1.1.7',
                'link' => 'https://www.pluginhive.com/product/woocommerce-multiple-non-adjacent-bookings/'
            ),
            array(
                'name' => 'Booking Participant Groups',
                'version' => '1.0.3',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-create-groups-people-family-team/'
            ),
            array(
                'name' => 'Asset availabilty customization',
                'version' => '1.0.3',
                'link'  => 'https://www.pluginhive.com/knowledge-base/share-service-with-multiple-bookable-products-using-woocommerce-bookings/'
            ),
            array(
                'name' => 'Customise Maximum Bookings Per Slot',
                'version' => '1.0.3',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-add-ons-customise-maximum-bookings-per-slot/'
            ),
            array(
                'name' => 'Customise Maximum Bookings Per Slot for All Week',
                'version' => '1.0.1',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-add-ons-customise-maximum-bookings-per-slot/'
            ),
            array(
                'name' => 'Skip Checkout for Bookings',
                'version' => '1.0.3',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-add-ons-skip-cart-checkout/'
            ),
            array(
                'name' => 'Block Product Availability Based on Other Bookings',
                'version' => '1.0.3',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-addons-block-product-availability/'
            ),
            array(
                'name' => 'Block Bookings For Custom Order Status Customisation',
                'version' => '1.0.2',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-for-custom-order-status/',
            ),
            array(
                'name' => 'Booking Resource Quantity',
                'version' => '1.0.4',
                'link' => 'https://www.pluginhive.com/knowledge-base/woocommerce-bookings-add-ons-set-and-manage-resource-quantity/'
            ),
        );
        
        $site_plugins = array();
        $author = array('PluginHive', 'pluginhive', 'Pluginhive', 'Varun, PluginHive');
        foreach (get_plugins() as $key => $plugin) 
        {
            if(in_array(trim($plugin['AuthorName']), $author))
            {
                $site_plugins[] = array('name' => $plugin['Name'], 'version' => $plugin['Version']);
            }
        }
        
        $plugins_present = array();
        $updates_remaining = array();
        foreach ($site_plugins as $plugin) 
        {
            if(in_array($plugin['name'], array_column($fixed_plugins, 'name')))
            {
                $plugins_present[] = $plugin;
                $search_key = array_search($plugin['name'], array_column($fixed_plugins, 'name'));
                $latest_plugin = $fixed_plugins[$search_key];
                if(version_compare($plugin['version'], $latest_plugin['version'], '<'))
                {
                    $updates_remaining[] = $plugin;
                }
            }
        }

        if(is_array($updates_remaining) && count($updates_remaining) <= 0)
        {
            update_option('ph_migration_plugins_updated_v3_0_0', 'yes');
        }
        else{
            update_option('ph_migration_plugins_updated_v3_0_0', 'no');
        }

        // Wordpress Required Environment
        $environment = array();
        if(function_exists('wc'))
        {
            global $wpdb;
            $report             = wc()->api->get_endpoint_data( '/wc/v3/system_status' );
            $environment        = $report['environment'];
        }
        
        $required_wp_env = array(
            'php_version'   => '7.0',
            'wp_version'    => '5.0',
            'wc_version'    => '3.0.0',
            'wp_memory_limit' => 536870912,        //512 MB
            'php_max_execution_time' => 300,
            'php_max_input_vars' => 2000,
            'ph_availability_table_exists' => true
        );

        $current_wp_env = array(
            'php_version'   => $environment['php_version'],
            'wp_version'    => $environment['wp_version'],
            'wc_version'    => $environment['version'],
            'wp_memory_limit' => $environment['wp_memory_limit'],
            'php_max_execution_time' => $environment['php_max_execution_time'],
            'php_max_input_vars' => $environment['php_max_input_vars'],
            'ph_availability_table_exists' => Phive_Bookings_Database::ph_availability_table_exists()
        );

        $wp_env_not_fixed = array();

        foreach ($current_wp_env as $key => $value) 
        {
            if(in_array($key, array('php_version', 'wp_version', 'wc_version')))
            {
                if(version_compare($value, $required_wp_env[$key], '<'))
                {
                    $wp_env_not_fixed[] = $key;
                }
            }
            else if($key == 'ph_availability_table_exists'){
                if($value === false){
                    $wp_env_not_fixed[] = $key;
                }
            }
            else{
                if($value < $required_wp_env[$key]){
                    $wp_env_not_fixed[] = $key;
                }
            }
        }

        if(is_array($wp_env_not_fixed) && count($wp_env_not_fixed) <= 0){
            update_option('ph_migration_env_set_v3_0_0', 'yes');
        }
        else{
            update_option('ph_migration_env_set_v3_0_0', 'no');
        }

        // 170706, 170543 - Option to bypass the environment check and complete the migration process
        if(isset($_REQUEST['ph_env_check_skip']) && is_array($_REQUEST['ph_env_check_skip']))
        {
            foreach ($_REQUEST['ph_env_check_skip'] as $env_name)
            {
                update_option('ph_migration_skipped_env_check_for_'.$env_name.'_v3_0_0', 'yes');
            }

            update_option('ph_migration_skip_env_check_v3_0_0', 'yes');
        }

        $ph_migration_instructions_read = get_option('ph_migration_instructions_read_v3_0_0', 'no');
        $ph_migration_plugins_updated   = get_option('ph_migration_plugins_updated_v3_0_0', 'no');
        $ph_migration_env_set           = get_option('ph_migration_env_set_v3_0_0', 'no');
        $ph_migration_final_consent     = get_option('ph_migration_final_consent_v3_0_0', 'no');

        // 170706, 170543 - Option to bypass the environment check and complete the migration process
        $ph_migration_skip_env_check    = get_option('ph_migration_skip_env_check_v3_0_0', 'no');
    ?>

    <div id="regForm">
        <h1>Bookings 3.0.0 Database Update</h1>
        <div class="tab" id="ph-migration-tab-info">
            <br>
            <!-- <h2>Migrate Data</h2> -->
            <p>
                Bookings Release 3.0.0 contains changes in the availability calculation to enhance the <strong>calendar performance and loading speed</strong>. 
                If you have this plugin running on your live site, please test this change on a staging server before you apply it on your live site.
                <br> <br>
                Please note, the plugin update to 3.0.0 alone will not cause any changes to the current version until all the further steps are completed.
            </p>
            <?php if($ph_migration_instructions_read != 'yes'){ ?>
            <form action="<?php admin_url( 'admin.php' ); ?>" style="" method="GET">
                <input type="hidden" name="page" value="bookings-settings">
                <input type="hidden" name="tab" value="booking-migrate-availability-data">
                <input type="hidden" name="ph_migration_instructions_read" id="ph_migration_instructions_read" value="yes">
                <div style="overflow:auto;">
                    <div style="float:right;">
                        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                        <button type="submit" id="nextBtn" onclick="nextPrev(1)">Next</button>
                    </div>
                </div>
            </form>
            <?php } else { ?>
            <div style="overflow:auto;">
                <div style="float:right;">
                    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                </div>
            </div>
            <?php } ?>
        </div>

        <div class="tab" id="ph-migration-tab-plugins">
            <br>
            <h2>Bookings Add-On Plugins Update for 3.0.0 compatibility:</h2>
            <?php if($ph_migration_plugins_updated != 'yes') 
                {
                    ?>
                    <div>
                        <h2>Plugins required to be updated:</h2>
                        <ul>
                            <?php
                                foreach($updates_remaining as $key => $plugin)
                                {
                                    $search_key  = array_search($plugin['name'], array_column($fixed_plugins, 'name'));
                                    $required_v  = $fixed_plugins[$search_key]['version'];
                                    $plugin_link = $fixed_plugins[$search_key]['link'];
                                    ?>
                                    <li><?php echo ($key+1).'. <a href="'.$plugin_link.'" target="_blank">'.$plugin['name'].' ('.$required_v.') </a>'; ?></li>
                                    <?php
                                }
                            ?>
                        </ul>
                    </div>
                    <br>
                    <div>
                        <h2>Plugins up to date:</h2>
                        <ul>
                            <?php
                                $plugins_updated = array_diff(array_column($plugins_present, 'name'), array_column($updates_remaining, 'name'));
                                $i = 0;
                                foreach( $plugins_updated as $key => $plugin)
                                {
                                    $search_key = array_search($plugin, array_column($fixed_plugins, 'name'));
                                    $required_v = $fixed_plugins[$search_key]['version'];
                                    ?>
                                    <li><?php echo ($i+1).'. '.$plugin.' ('.$required_v.')'; ?></li>
                                    <?php
                                    $i++;
                                }
                            ?>
                        </ul>
                    </div>
                    
                    <form action="<?php admin_url( 'admin.php' ); ?>" style="" method="GET">
                        <input type="hidden" name="page" value="bookings-settings">
                        <input type="hidden" name="tab" value="booking-migrate-availability-data">
                        <div style="overflow:auto;">
                            <div style="float:right;">
                                <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                                <button type="submit" id="nextBtn" onclick="nextPrev(1)" class="<?php echo ($ph_migration_plugins_updated != 'yes') ? 'disabled' : ''; ?>">Next</button>
                            </div>
                        </div>
                    </form>
                    <?php 
                }
                else{
                    if(is_array($plugins_present) && count($plugins_present) > 0)
                    {
                        ?>
                        <h2>Plugins updated to latest:</h2>
                        <ul>
                            <?php
                                foreach($plugins_present as $key => $plugin)
                                {
                                    $search_key = array_search($plugin['name'], array_column($fixed_plugins, 'name'));
                                    $required_v = $fixed_plugins[$search_key]['version'];
                                    ?>
                                    <li><?php echo ($key+1).'. '.$plugin['name'].' ('.$required_v.')'; ?></li>
                                    <?php
                                }
                            ?>
                        </ul>
                        <?php
                    }
                    else
                    {
                        ?>
                            <p>If you have any of the Bookings Add-on Plugins installed, they need to be updated to the latest version for 3.0.0 compatibility.</p>
                        <?php
                    }
                    ?> 
                    <div style="overflow:auto;">
                        <div style="float:right;">
                            <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                            <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                        </div>
                    </div>
                    <?php
                } 
            ?>
        </div>

        <div class="tab" id="ph-migration-tab-env">
            <br>
            <h2 style="padding-left:11px; margin-bottom:0;">Bookings 3.0.0 Environment pre-requisite for version 3.0.0 compatibility:</h2>
            <table>
                <tr>
                    <td style="padding-right:30px;">
                        <h2 style="padding-left:10px">Required WordPress Environment</h2>
                        <table style="text-align:left">
                            <tr>
                                <th>PHP Version</th>
                                <td>>= 7.0</td>
                            </tr>
                            <tr>
                                <th>WordPress Version</th>
                                <td>>= 5.0</td>
                            </tr>
                            <tr>
                                <th>Woocommerce Version</th>
                                <td>>= 3.0.0</td>
                            </tr>
                            <tr>
                                <th>WordPress memory limit</th>
                                <td>>= 512 MB</td>
                            </tr>
                            <tr>
                                <th>PHP time limit</th>
                                <td>>= 300 (seconds)</td>
                            </tr>
                            <tr>
                                <th>PHP max input vars</th>
                                <td>>= 2000</td>
                            </tr>
                            <tr>
                                <th>Availability Table Created</th>
                                <td>Yes</td>
                            </tr>
                        </table>
                    </td>
                    <td style="padding-left:30px;">
                        <h2 style="padding-left:10px">Current WordPress Environment</h2>
                        <table style="text-align:left">
                            <tr>
                                <th>PHP Version</th>
                                <td class="<?php echo (in_array('php_version', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>"><?php echo $current_wp_env['php_version']; ?></td>
                                <td>
                                    <?php
                                        if(in_array('php_version', $wp_env_not_fixed))
                                        {
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="php_version" value="yes" style="display:none;"><?php
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>WordPress Version</th>
                                <td class="<?php echo (in_array('wp_version', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>"><?php echo $current_wp_env['wp_version']; ?></td>
                                <td>
                                    <?php
                                        if(in_array('wp_version', $wp_env_not_fixed))
                                        {
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="wp_version" value="yes" style="display:none;"><?php
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Woocommerce Version</th>
                                <td class="<?php echo (in_array('wc_version', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>"><?php echo $current_wp_env['wc_version']; ?></td>
                                <td>
                                    <?php
                                        if(in_array('wc_version', $wp_env_not_fixed))
                                        {
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="wc_version" value="yes" style="display:none;"><?php
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>WordPress memory limit</th>
                                <td class="<?php echo (in_array('wp_memory_limit', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>"><?php echo size_format($current_wp_env['wp_memory_limit']); ?></td>
                                <td>
                                    <?php
                                        if(in_array('wp_memory_limit', $wp_env_not_fixed))
                                        {
                                            $wp_memory_limit_skip_status = get_option('ph_migration_skipped_env_check_for_wp_memory_limit_v3_0_0', 'no');
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="wp_memory_limit" value="yes" <?php if($wp_memory_limit_skip_status == 'yes'){echo "checked disabled";} ?>> Skip Environment Check<?php
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>PHP time limit</th>
                                <td class="<?php echo (in_array('php_max_execution_time', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>"><?php echo $current_wp_env['php_max_execution_time']; ?></td>
                                <td>
                                    <?php
                                        if(in_array('php_max_execution_time', $wp_env_not_fixed))
                                        {
                                            $php_max_execution_time_skip_status = get_option('ph_migration_skipped_env_check_for_php_max_execution_time_v3_0_0', 'no');
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="php_max_execution_time" value="yes" <?php if($php_max_execution_time_skip_status == 'yes'){echo "checked disabled";} ?>> Skip Environment Check<?php
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>PHP max input vars</th>
                                <td class="<?php echo (in_array('php_max_input_vars', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>"><?php echo $current_wp_env['php_max_input_vars']; ?></td>
                                <td>
                                    <?php
                                        if(in_array('php_max_input_vars', $wp_env_not_fixed)){
                                            $php_max_input_vars_skip_status = get_option('ph_migration_skipped_env_check_for_php_max_input_vars_v3_0_0', 'no');
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="php_max_input_vars" value="yes" <?php if($php_max_input_vars_skip_status == 'yes'){echo "checked disabled";} ?>> Skip Environment Check<?php
                                        }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Availability Table Created</th>
                                <td class="<?php echo (in_array('ph_availability_table_exists', $wp_env_not_fixed)) ? 'env-not-fixed' : 'env-fixed'?>">
                                    <?php echo ($current_wp_env['ph_availability_table_exists'] === true) ? 'Yes' : 'No'; ?>
                                </td>
                                <td>
                                    <?php
                                        if(in_array('ph_availability_table_exists', $wp_env_not_fixed)){
                                            ?>&nbsp;&nbsp;<input type="checkbox" class="ph-skip-environment-check" name="ph_availability_table_exists" value="yes" style="display:none;"><?php
                                        }
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <br>
            <div style="padding-left:11px;">
                <strong><?php _e('Note:', 'bookings-and-appointments-for-woocommerce'); ?></strong>
                <?php _e('You can skip certain environment checks if necessary. However, it is recommended to follow the above guideline in order to avoid memory issues in case of high volume of bookings data.', 'bookings-and-appointments-for-woocommerce'); ?>
                <br><br>
            </div>
            <?php if($ph_migration_env_set != 'yes' && $ph_migration_skip_env_check != 'yes') {?>
                <form action="<?php admin_url( 'admin.php' ); ?>" style="" method="GET">
                    <input type="hidden" name="page" value="bookings-settings">
                    <input type="hidden" name="tab" value="booking-migrate-availability-data">
                    <br>
                    <?php
                        $class = '';
                        if($ph_migration_env_set != 'yes'){
                            $class = 'disabled';
                        }
                    ?>
                    <div style="overflow:auto;">
                        <div style="float:right;">
                            <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                            <button type="submit" id="nextBtn" class="<?php echo $class; ?>" onclick="nextPrev(1)">Next</button>
                        </div>
                    </div>
                </form>
            <?php } else { ?>
                <div style="overflow:auto;">
                    <div style="float:right;">
                        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                        <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                    </div>
                </div>
            <?php } ?>
        </div>

        <div class="tab" id="ph-migration-tab-consent">
            <br>
            <form action="<?php admin_url( 'admin.php' ); ?>" style="" method="GET">
                <input type="hidden" name="page" value="bookings-settings">
                <input type="hidden" name="tab" value="booking-migrate-availability-data">
                <br>
                <p>
                    This is the final step. After clicking <b>Next</b>, the data migration will begin.
                    <br> <br>
                    Please switch on the maintenance mode of your live site while the migration is on. If you face any issues during the migration please raise a ticket <a href="https://www.pluginhive.com/support/" target="_blank">here</a>. 
                </p>
                <p>Proceed ahead : </p>
                <div style="width:max-content;">
                    <div style="display:inline-block; padding: 0 10px;">
                        <input type="radio" name="ph_migration_final_consent" id="ph_migration_final_consent" value="yes" <?php echo ($ph_migration_final_consent == 'yes') ? 'checked disabled' : ''; ?>>
                        <label for="ph_migration_final_consent">Yes</label>
                    </div>
                    <div style="display:inline-block; padding:0 10px;">
                        <input type="radio" name="ph_migration_final_consent" id="ph_migration_final_consent" value="no"  <?php echo ($ph_migration_final_consent == 'no') ? 'checked' : 'disabled'  ?>>
                        <label for="ph_migration_final_consent">No</label>
                    </div>
                </div>
                <?php if($ph_migration_final_consent != 'yes') {?>
                    <div style="overflow:auto;">
                        <div style="float:right;">
                            <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                            <button type="submit" id="nextBtn" onclick="nextPrev(1)">Next</button>
                        </div>
                    </div>
                <?php } ?>
            </form>
            <?php if($ph_migration_final_consent == 'yes'){ ?>
                <div style="overflow:auto;">
                    <div style="float:right;">
                        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                        <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                    </div>
                </div>
            <?php } ?>
        </div>

        <div class="tab" id="ph-migration-tab-progress">
            <?php
               $migration = array(
                    'migration_consent'     => 'no',                    //yes or no	- default no
                    'started'				=> 'no',					//yes or no	- default no
                    'fetched_data'			=> 'no',					//yes or no	- default no
                    'table_prepared'		=> 'no',					//yes or no	- default no
                    'completed' 			=> 'no',					//yes or no - default no
                    'partial'				=> 'no',					//yes or no - default no
                    'order_ids'				=> array(),
                    'order_ids_left' 		=> array(),
                    'order_ids_migrated' 	=> array()
                );
                $option_name    = 'ph_migrate_availability_data_v3_0_0';
                $migration      = get_option($option_name, $migration);

                if(isset($migration['migration_consent']) && $migration['migration_consent'] == 'yes')
                {
                    include_once('html-ph-migrate-data-to-availability-table-progress.php');
                }
            ?>
            <div style="overflow:auto;">
                <div style="">
                    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                </div>
            </div>
        </div>

        <!-- Circles which indicates the steps of the form: -->
        <div style="text-align:center;margin-top:40px;">
            <span class="step"></span>
            <span class="step"></span>
            <span class="step"></span>
            <span class="step"></span>
            <span class="step"></span>
        </div>
    </div>

    <script>

        // 170706, 170543 - Option to bypass the environment check and complete the migration process
        jQuery('.ph-skip-environment-check').on('click', function()
        {
            var all_elements_for_skip = jQuery('.ph-skip-environment-check');
            all_elements_for_skip = Array.from(all_elements_for_skip);

            var total_elements = all_elements_for_skip.length;
            var elements_checked = 0;
            var skipped_elements = [];

            all_elements_for_skip.forEach(elements_for_skip => {
                if(jQuery(elements_for_skip).is(":checked")){
                    elements_checked++;
                    skipped_elements.push(jQuery(elements_for_skip).attr('name'));
                }
            });

            parent          = jQuery(this).parents('#ph-migration-tab-env');
            form            = parent.find('form');
            submitbutton    = form.find('button#nextBtn');
            if(total_elements == elements_checked)
            {
                submitbutton.removeClass('disabled');
                var appendHtml = '';
                if(skipped_elements.length){
                    skipped_elements.forEach(skipped_element => {
                        appendHtml += `<input type="hidden" name="ph_env_check_skip[]" value="`+skipped_element+`">`; 
                    });
                }
                form.append(appendHtml);
            }
            else{
                submitbutton.addClass('disabled');
                remove_inputs = jQuery('input[name="ph_env_check_skip[]"]');
                if(remove_inputs)
                {
                    remove_inputs = Array.from(remove_inputs);
                    remove_inputs.forEach(remove_input => {
                        remove_input.remove();
                    });
                }
            }
        });

        var currentTab = 0; // Current tab is set to be the first tab (0)
        
        currentTab = "<?php echo $ph_migration_instructions_read == 'no' ? 0 : ($ph_migration_plugins_updated == 'no' ? 1 : (($ph_migration_env_set == 'no' && $ph_migration_skip_env_check == 'no') ? 2 : ($ph_migration_final_consent == 'no' ? 3 : 4)))?>";

        showTab(currentTab); // Display the current tab

        function showTab(n) {
            // This function will display the specified tab of the form...
            var x = document.getElementsByClassName("tab");

            console.log(n);

            x[n].style.display = "block";
            //... and fix the Previous/Next buttons:
            if (n == 0) {
                document.getElementById("prevBtn").style.display = "none";
            } else {
                document.getElementById("prevBtn").style.display = "inline";
            }
            if (n == (x.length - 1)) {
                // document.getElementById("nextBtn").innerHTML = "Submit";
                document.getElementById("nextBtn").innerHTML = "";
            } else {
                document.getElementById("nextBtn").innerHTML = "Next";
            }
            //... and run a function that will display the correct step indicator:
            fixStepIndicator(n)
        }

        // This function will figure out which tab to display
        function nextPrev(n) {
            var x = document.getElementsByClassName("tab");

            // Hide the current tab:
            x[currentTab].style.display = "none";

            // Increase or decrease the current tab by 1:
            currentTab = parseInt(currentTab) + parseInt(n);
            
            // if you have reached the end of the form...
            if (currentTab >= x.length) {
                return false;
            }
            // Otherwise, display the correct tab:
            showTab(currentTab);
        }

        function fixStepIndicator(n) {
            // This function removes the "active" class of all steps...
            var i, x = document.getElementsByClassName("step");
            for (i = 0; i < x.length; i++) {
                x[i].className = x[i].className.replace(" active", "");
            }
            //... and adds the "active" class on the current step:
            x[n].className += " active";
        }

    </script>

</body>

</html>