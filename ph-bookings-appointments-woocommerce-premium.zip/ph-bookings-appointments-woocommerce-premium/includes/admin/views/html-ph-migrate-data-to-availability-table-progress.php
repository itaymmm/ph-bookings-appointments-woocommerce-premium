<?php
$ph_migration_list_table = new Ph_Migrate_Data_Progress_List_Table();
$ph_migration_list_table->prepare_items();
?>
    <div class="wrap">
        <div id="icon-users" class="icon32"></div>
        <h2>
            Migration Progress
        </h2>
        <a href="">Refresh</a>
        <p style="margin-bottom:0;">
            <?php
                _e('Only Orders From Future Booking Date Will Be Migrated. None of your booking data will be affected.', 'bookings-and-appointments-for-woocommerce');
                echo '&nbsp;';
                _e('This may take a while. Please wait/refresh till you see the <strong>“Process completed”</strong> message.', 'bookings-and-appointments-for-woocommerce');
            ?>
        </p>
        <br>
        <?php
            $migration          = $ph_migration_list_table->get_migration_option();
            $orders_to_migrate  = (!empty($migration['order_ids'])) ? count($migration['order_ids']) : 0;
            $order_migrated     = (!empty($migration['order_ids_migrated'])) ? count($migration['order_ids_migrated']) : 0;
            $progress           = ($migration['started'] == 'yes' && ($orders_to_migrate == $order_migrated)) ? '100%' : '';      
            if($progress == '100%')
            {
                ?>
                <div class="alert alert-success" role="alert">
                    <?php _e('Migration Process Completed!', 'bookings-and-appointments-for-woocommerce'); ?>
                </div>
                <?php
            }
        ?>
        <?php $ph_migration_list_table->display(); ?>
    </div>
<?php

// WP_List_Table is not loaded automatically so we need to load it in our application
if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/**
 * Create a new table class that will extend the WP_List_Table
 */
class Ph_Migrate_Data_Progress_List_Table extends WP_List_Table
{
    /**
     * Prepare the items for the table to process
     *
     * @return Void
     */
    public function prepare_items()
    {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $data = $this->table_data();
        usort( $data, array( &$this, 'sort_data' ) );

        $perPage = 5;
        $currentPage = $this->get_pagenum();
        $totalItems = count($data);

        $this->set_pagination_args( array(
            'total_items' => $totalItems,
            'per_page'    => $perPage
        ) );

        $data = array_slice($data,(($currentPage-1)*$perPage),$perPage);

        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $data;
    }

    /**
     * Override the parent columns method. Defines the columns to use in your listing table
     *
     * @return Array
     */
    public function get_columns()
    {
        $columns = array(
            'id'            => 'ID',
            'title'         => 'Title',
            'details'       => 'Details',
        );

        return $columns;
    }

    /**
     * Define which columns are hidden
     *
     * @return Array
     */
    public function get_hidden_columns()
    {
        return array();
    }

    /**
     * Define the sortable columns
     *
     * @return Array
     */
    public function get_sortable_columns()
    {
        // return array('title' => array('title', false));
        return array();
    }

    /**
     * Get the table data
     *
     * @return Array
     */
    private function table_data()
    {
        $migration = $this->get_migration_option();

        $data = array();

        if(isset($migration['fetched_data']) && $migration['fetched_data'] == 'yes')
        {
            $orders_to_migrate  = (!empty($migration['order_ids'])) ? count($migration['order_ids']) : 0;
            $order_migrated     = (!empty($migration['order_ids_migrated'])) ? count($migration['order_ids_migrated']) : 0;
            $order_left         = (!empty($migration['order_ids_left'])) ? count($migration['order_ids_left']) : (($migration['completed'] != 'yes') ? 'Counting... Please Refresh.' : 0);
            $progress           = ($migration['started'] == 'yes' && ($orders_to_migrate == $order_migrated)) ? '100%' : '';      
            if($progress != '100%'){
                $progress = ($order_migrated/$orders_to_migrate) * 100;
            }

            $data[] = array(
                'id'        => 1,
                'title'     => 'Progress',
                'details'   => $progress,
                );

            $data[] = array(
                'id'        => 2,
                'title'     => 'Orders To Migrate',
                'details'   => $orders_to_migrate,
                );

            $data[] = array(
                'id'        => 3,
                'title'     => 'Orders Migrated',
                'details'   => $order_migrated,
                );

            $data[] = array(
                'id'        => 4,
                'title'     => 'Orders Left',
                'details'   => $order_left,
                );
        }
    
        return $data;
    }

    /**
     * Define what data to show on each column of the table
     *
     * @param  Array $item        Data
     * @param  String $column_name - Current column name
     *
     * @return Mixed
     */
    public function column_default( $item, $column_name )
    {
        switch( $column_name ) {
            case 'id':
            case 'title':
            case 'details':
                return $item[ $column_name ];
            default:
                return print_r( $item, true ) ;
        }
    }

    public function get_migration_option()
    {
        $migration = array(
            'migration_consent'     => 'no',                    //yes or no	- default no
            'started'				=> 'no',					//yes or no	- default no
            'fetched_data'			=> 'no',					//yes or no	- default no
            'table_prepared'		=> 'no',					//yes or no	- default no
            'completed' 			=> 'no',					//yes or no - default no
            'partial'				=> 'no',					//yes or no - default no
            'order_ids'				=> array(),
            'order_ids_left' 		=> array(),
            'order_ids_migrated' 	=> array()
        );

        $option_name  = 'ph_migrate_availability_data_v3_0_0';
        $migration    = get_option($option_name, $migration);

        return $migration;
    }
}
?>