<?php
/**
 * @since 3.0.0
 * php          7.0 and above
 * wordpress    5.0 and above
 * woocommerce  3.0.0 and above should work. wc_get_order was added in 2.6.0
 */
defined( 'ABSPATH' ) or exit;

if ( ! class_exists( 'Phive_Bookings_Migrate_Data' ) ) 
{
	class Phive_Bookings_Migrate_Data
    {

        /**
         * @var $availability_tablename
         */
        public $availability_tablename;

        /**
         * @var $migration
         */
        public $migration;

        /**
         * @var $option_name
         */
        public $option_name;

        /**
         * @var $logger
         */
        public $logger;

        /**
         * @var $context
         */
        public $context;

		public function __construct() 
        {
            $this->availability_tablename = 'ph_bookings_availability_calculation_data';            
            $this->migration = array(
                'migration_consent'     => 'no',                    //yes or no	- default no
                'started'				=> 'no',					//yes or no	- default no
                'fetched_data'			=> 'no',					//yes or no	- default no
                'table_prepared'		=> 'no',					//yes or no	- default no
                'completed' 			=> 'no',					//yes or no - default no
                'partial'				=> 'no',					//yes or no - default no
                'order_ids'				=> array(),
                'order_ids_left' 		=> array(),
                'order_ids_migrated' 	=> array()
            );

            $this->option_name  = 'ph_migrate_availability_data_v3_0_0';
            $this->migration    = get_option($this->option_name, $this->migration);

            add_action( 'admin_notices', array($this, 'update_needed_notice') );

            if($this->migration['completed'] != 'yes' && $this->migration['migration_consent'] == 'yes')
            {
                add_action( 'init', array($this, 'ph_bookings_migrate_data_check_v3_0_0') );
            }
            elseif($this->migration['completed'] == 'yes')
            {
                $setting_modified = get_option('ph_migration_modified_display_setting_v3_0_0');
                $display_settings = get_option('ph_bookings_display_settigns');
                if($setting_modified != 'yes')
                {
                    $display_settings['calculate_availability_using_availability_table'] = 'yes';
                    update_option('ph_bookings_display_settigns', $display_settings);
                    update_option('ph_migration_modified_display_setting_v3_0_0', 'yes');
                }
            }
		}
        
        public function ph_bookings_migrate_data_check_v3_0_0()
        {
            $this->logger = wc_get_logger();
            $this->context = array( 'source' => 'ph_bookings_availability_data_migration_v3_0_0' );
            $started    = isset($this->migration['started']) ? $this->migration['started'] : 'no';
            $partial    = isset($this->migration['partial']) ? $this->migration['partial'] : 'no';
            $completed  = isset($this->migration['completed']) ? $this->migration['completed'] : 'no';
            if(isset($this->migration['fetched_data']) && $this->migration['fetched_data'] == 'no')
            {
                $this->fetch_data();
            }
            else if($completed == 'no')
            {
                $this->start_migration();
            }
        }

        public function fetch_data()
        {
            try
            {
                $current_date = strtotime(date("Y-m-d"));
                $compare_date = date ( "Y-m-d", strtotime( "-3 day", $current_date ) ) ;

                global $wpdb;
                $query = "SELECT 
                        oitems.order_item_id, 
                        oitems.order_id, 
                        oimeta.book_from,
                        oimeta.book_to, 
                        oimeta.product_id, 
                        oimeta.booking_status, 
                        oimeta.participant_count, 
                        oimeta.asset_id, 
                        oimeta.person_as_booking,
                        oimeta.interval_format, 
                        oimeta.interval_number, 
                        oimeta.buffer_before_id, 
                        oimeta.buffer_after_id,
                        wposts.ID, 
                        wposts.buffer_after_to, 
                        wposts.buffer_after_from, 
                        wposts.buffer_asset_id
                        FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                        INNER JOIN
                        (
                            SELECT order_item_id,
                            MAX(CASE WHEN meta_key = 'From' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, '\"', 2), '\"', -1) ELSE '' END) AS book_from,
                            MAX(CASE WHEN meta_key = 'To' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, '\"', 2), '\"', -1) ELSE '' END) AS book_to,
                            MAX(CASE WHEN meta_key = '_product_id' THEN meta_value ELSE '' END) AS product_id,
                            MAX(CASE WHEN meta_key = 'booking_status' THEN meta_value ELSE '' END) AS booking_status,
                            MAX(CASE WHEN meta_key = 'Number of persons' THEN meta_value ELSE 0 END) AS participant_count,
                            MAX(CASE WHEN meta_key = 'Assets' THEN meta_value ELSE '' END) AS asset_id,
                            MAX(CASE WHEN meta_key = 'person_as_booking' THEN meta_value ELSE '' END) AS person_as_booking,
                            MAX(CASE WHEN meta_key = '_phive_booking_product_interval_details' THEN (SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -1), '\"', 1)) ELSE '' END) AS interval_format,
                            MAX(CASE WHEN meta_key = '_phive_booking_product_interval_details' THEN (SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -3), '\"', 1)) ELSE '' END) AS interval_number,
                            MAX(CASE WHEN meta_key = 'buffer_before_id' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -1), '\";', 1) ELSE '' END) AS buffer_before_id,
                            MAX(CASE WHEN meta_key = 'buffer_after_id' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -1), '\";', 1) Else '' END) AS buffer_after_id
                            FROM {$wpdb->prefix}woocommerce_order_itemmeta
                            GROUP BY order_item_id
                        ) AS oimeta ON oimeta.order_item_id = oitems.order_item_id
                        INNER JOIN {$wpdb->prefix}term_relationships AS tr ON tr.object_id = oimeta.product_id
                        INNER JOIN {$wpdb->prefix}term_taxonomy AS tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                        INNER JOIN {$wpdb->prefix}terms AS t ON t.term_id = tt.term_id
                        LEFT JOIN
                        (
                            SELECT {$wpdb->prefix}posts.ID,
                            MAX(CASE WHEN {$wpdb->prefix}postmeta.meta_key = 'Buffer_after_To' THEN {$wpdb->prefix}postmeta.meta_value ELSE '' END) AS buffer_after_to,
                            MAX(CASE WHEN {$wpdb->prefix}postmeta.meta_key = 'Buffer_after_From' THEN {$wpdb->prefix}postmeta.meta_value ELSE '' END) AS buffer_after_from,
                            MAX(CASE WHEN {$wpdb->prefix}postmeta.meta_key = 'buffer_asset_id' THEN {$wpdb->prefix}postmeta.meta_value ELSE '' END) AS buffer_asset_id
                            FROM {$wpdb->prefix}posts
                            INNER JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}posts.ID = {$wpdb->prefix}postmeta.post_id
                            GROUP BY {$wpdb->prefix}posts.ID
                        ) AS wposts ON wposts.ID = oimeta.buffer_after_id
                        WHERE t.slug = 'phive_booking' and tt.taxonomy = 'product_type' AND 
                        DATE(
                            IF(
                                NOT (ISNULL(wposts.buffer_after_to) OR wposts.buffer_after_to = ''),
                                wposts.buffer_after_to,
                                IF (
                                    NOT (ISNULL(wposts.buffer_after_from) OR wposts.buffer_after_from = ''),
                                    wposts.buffer_after_from,
                                    IF
                                    (
                                        (
                                            NOT (ISNULL(oimeta.book_to) OR oimeta.book_to = '') AND (NOT (ISNULL(oimeta.interval_format) OR oimeta.interval_format = '') )
                                        ),
                                        IF(
                                            (
                                                (NOT oimeta.interval_format = 'day') AND (NOT oimeta.interval_format = 'month')
                                            ),
                                            IF(
                                                oimeta.interval_format = 'hour',
                                                DATE_ADD(oimeta.book_to, INTERVAL oimeta.interval_number HOUR),
                                                DATE_ADD(oimeta.book_to, INTERVAL oimeta.interval_number MINUTE)
                                            ),
                                            IF(
                                                oimeta.interval_format = 'month',
                                                LAST_DAY(CONCAT(oimeta.book_to, '-01')),
                                                oimeta.book_to
                                            )
                                        ),
                                        IF(
                                            ( 
                                                ( ISNULL(oimeta.book_to) OR oimeta.book_to = '' ) AND 
                                                ( NOT (ISNULL(oimeta.interval_format) OR oimeta.interval_format = '') )
                                            ),
                                            IF(
                                                (
                                                    (oimeta.interval_format = 'day' || oimeta.interval_format = 'month')
                                                ),
                                                (
                                                    IF(
                                                        oimeta.interval_number > 1,
                                                        (
                                                            IF(
                                                                oimeta.interval_format = 'day',
                                                                DATE_ADD(oimeta.book_from, INTERVAL (oimeta.interval_number-1) Day),
                                                                DATE_ADD(LAST_DAY(CONCAT(oimeta.book_from, '-01')), INTERVAL (oimeta.interval_number-1) Month)
                                                            )
                                                        ),
                                                        IF(
                                                            oimeta.interval_format = 'month',
                                                            LAST_DAY(CONCAT(oimeta.book_from, '-01')),
                                                            oimeta.book_from
                                                        )
                                                    )
                                                ),
                                                (
                                                    IF(
                                                        oimeta.interval_format = 'hour',
                                                        DATE_ADD(oimeta.book_from, INTERVAL oimeta.interval_number HOUR),
                                                        DATE_ADD(oimeta.book_from, INTERVAL oimeta.interval_number MINUTE)
                                                    )
                                                )
                                            ),
                                            IF(
                                                LENGTH(oimeta.book_from) = 7,
                                                LAST_DAY(CONCAT(oimeta.book_from, '-01')),
                                                oimeta.book_from
                                            )
                                        )
                                    )
                                )
                            )
                        ) >= '$compare_date'
                        ORDER BY `oimeta`.`book_to` DESC";
                $data       = $wpdb->get_results( $query, OBJECT );
                $order_ids  = array();
                $invalid_order_ids = array();
                foreach ($data as $key => $value) {
                    $order = wc_get_order($value->order_id);
                    if(!(is_object($order)))
                    {
                        // Migration Improvement - Deleted/Invalid orders should not be added for migration
                        $invalid_order_ids[] = $value->order_id;
                        continue;
                    }
                    $order_ids[] = $value->order_id;
                }
                update_option('ph_migration_invalid_order_ids_not_migrated_v3_0_0', $invalid_order_ids);

                if(empty($order_ids)){
                    $this->migration['order_ids'] = $this->migration['order_ids_left'] = array();
                    $this->migration['fetched_data'] = $this->migration['started'] = $this->migration['completed'] = 'yes';
                }
                else{
                    $this->migration['order_ids'] = $this->migration['order_ids_left'] = array_values(array_unique($order_ids));
                    $this->migration['fetched_data'] = 'yes';
                }
                update_option($this->option_name, $this->migration);
            }
            catch(Throwable $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'fetch_data', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );
            }
            catch(Exception $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'fetch_data', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );
            }
            if($this->migration['completed'] != 'yes' && $this->migration['migration_consent'] == 'yes')
            {
                $this->start_migration();
            }
        }

        public function start_migration()
        {
            if(isset($this->migration['fetched_data']) && $this->migration['fetched_data'] == 'yes')
            {
                if($this->isset_and_not_empty($this->migration['order_ids']))
                {
                    $this->empty_availability_table_before_migration_started();
                    $this->migrate_data($this->migration['order_ids']);
                }
                else
                {
                    // error_log('Nothing to migrate. All Set!');
                    $this->migration['started'] = $this->migration['completed'] = 'yes';
                    $this->migration['table_prepared'] = 'yes';
                    update_option($this->option_name, $this->migration);
                }
            }
        }

        public function isset_and_not_empty($variable)
        {
            return (isset($variable) && !empty($variable));
        }

        public function migrate_data($order_ids)
        {
            $this->migration['started'] = 'yes';
            try
            {
                if($this->migration['table_prepared'] != 'yes')
                {
                    return;
                }

                $order_ids_availability_table   = $this->get_order_ids_from_availability_table();
                $order_ids_migrated             = array_values(array_intersect($order_ids, $order_ids_availability_table));
                $order_ids_to_migrate = $order_ids_left = array_values(array_diff($order_ids, $order_ids_availability_table));

                if(count($order_ids_migrated) > 0)
                {
                    $this->migration['partial']             = 'yes';
                    $this->migration['order_ids_migrated']  = array_values(array_unique(array_merge($this->migration['order_ids_migrated'], $order_ids_migrated)));
                    $this->migration['order_ids_left']      = $order_ids_left;
                    update_option($this->option_name, $this->migration);
                }
                
                if(count($order_ids_to_migrate) == 0)
                {
                    $this->migration['partial']             = 'no';
                    $this->migration['completed']           = 'yes';
                    $this->migration['order_ids_migrated']  = array_values(array_unique(array_merge($this->migration['order_ids_migrated'], $order_ids_migrated)));
                    $this->migration['order_ids_left']      = array();
                    throw new Exception("Nothing to migrate");
                    update_option($this->option_name, $this->migration);
                }

                foreach ($order_ids_to_migrate as $order_id) 
                {
                    if(!empty($order_id))
                    {
                        $order = wc_get_order($order_id);
                        $this->ph_bookings_insert_data_in_availability_table_when_order_created_from_migration($order);
                        $order_ids_migrated[] = $order_id;
                    }
                }

                if((count($order_ids_migrated) > 0) && !(array_diff($order_ids, $order_ids_migrated)))
                {
                    $this->migration['partial']             = 'no';
                    $this->migration['completed']           = 'yes';
                    $this->migration['order_ids_migrated']  = array_values(array_unique(array_merge($this->migration['order_ids_migrated'], $order_ids_migrated)));
                    $this->migration['order_ids_left']      = array();
                    update_option($this->option_name, $this->migration);
                }
    
            }
            catch(Throwable $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'migrate_data', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );

            }
            catch(Exception $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'migrate_data', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );

            }
            update_option($this->option_name, $this->migration);
        }

        public function get_order_ids_from_availability_table()
        {
            $order_ids = array();
            try
            {
                $obj        = new Phive_Bookings_Database();
                $order_ids  = $obj->get_order_ids_from_availability_table();
            }
            catch(Throwable $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'get_order_ids_from_availability_table', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );
            }
            catch(Exception $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'get_order_ids_from_availability_table', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );
            }
            return $order_ids;
        }

        public function update_needed_notice() 
        {
            $migration = get_option($this->option_name, $this->migration);
            
            if($migration['completed'] == 'yes' || $this->is_new_site()){
                return;
            }

            // ph_migration_final_consent_v3_0_0
            $update_url =
                add_query_arg(
                    array(
                        'do_update_ph_bookings' => 'true',
                    ),
                    wc_get_current_admin_url() ? wc_get_current_admin_url() : admin_url( 'admin.php?page=bookings-settings&tab=booking-migrate-availability-data' )
                );

            $update_url = admin_url( 'admin.php?page=bookings-settings&tab=booking-migrate-availability-data' );
           
            ?>
            <div id="message" class="updated woocommerce-message wc-connect">
                <h3>
                    <strong><?php esc_html_e( 'Bookings Database Update Required', 'bookings-and-appointments-for-woocommerce' ); ?></strong>
                </h3>
                <p>
                    <?php
                        esc_html_e( '"Bookings and Appointments For WooCommerce Premium" has been updated! To keep things running smoothly, we have to update your database to the newest version.', 'bookings-and-appointments-for-woocommerce' );
                        /* translators: 1: Link to docs 2: Close link. */
                        echo ' ';
                        esc_html_e( 'The database update process runs in the background and may take a little while, so please be patient.', 'bookings-and-appointments-for-woocommerce' );
                    ?>
                </p>
                <p class="submit">
                    <a href="<?php echo esc_url( $update_url ); ?>" class="wc-update-now button-primary">
                        <?php esc_html_e( 'Update Bookings Database', 'bookings-and-appointments-for-woocommerce' ); ?>
                    </a>
                    <!-- <a href="" class="button-secondary">
                        <php esc_html_e( 'Learn more about updates', 'woocommerce' ); ?>
                    </a> -->
                </p>
            </div>
            <?php
        }

        public function empty_availability_table_before_migration_started()
        {
            $this->migration    = get_option($this->option_name, $this->migration);
            try
            {
                if(is_array($this->migration) && $this->migration['table_prepared'] == 'yes')
                {
                    return 1;
                }
                else if(is_array($this->migration))
                {
                    $obj        = new Phive_Bookings_Database();
                    $obj->empty_availability_table();
                    $this->migration['table_prepared'] = 'yes';
                    update_option($this->option_name, $this->migration);
                    return 1;
                }
            }
            catch(Throwable $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'empty_availability_table_before_migration_started', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );
            }
            catch(Exception $e)
            {
                $this->logger->debug( '____________________________________________', $this->context );
                $this->logger->debug( 'empty_availability_table_before_migration_started', $this->context );
                $this->logger->debug( '-------------------Errors-------------------', $this->context );
                $this->logger->debug( 
                print_r( 
                    array(
                    'code'      => $e->getCode(),
                    'message'	=> $e->getMessage(),
                    'file'      => $e->getFile(),
                    'line'      => $e->getLine(),
                    'time'		=> date('Y-m-d H:i:s'),
                ), 1), $this->context );
            }
        }

        public function is_new_site()
        {
            global $wpdb;
            $query = "SELECT 
                    oitems.order_item_id, 
                    oitems.order_id, 
                    oimeta.book_from,
                    oimeta.book_to, 
                    oimeta.product_id, 
                    oimeta.booking_status, 
                    oimeta.participant_count, 
                    oimeta.asset_id, 
                    oimeta.person_as_booking,
                    oimeta.interval_format, 
                    oimeta.interval_number, 
                    oimeta.buffer_before_id, 
                    oimeta.buffer_after_id,
                    wposts.ID, 
                    wposts.buffer_after_to, 
                    wposts.buffer_after_from, 
                    wposts.buffer_asset_id
                    FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                    INNER JOIN
                    (
                        SELECT order_item_id,
                        MAX(CASE WHEN meta_key = 'From' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, '\"', 2), '\"', -1) ELSE '' END) AS book_from,
                        MAX(CASE WHEN meta_key = 'To' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, '\"', 2), '\"', -1) ELSE '' END) AS book_to,
                        MAX(CASE WHEN meta_key = '_product_id' THEN meta_value ELSE '' END) AS product_id,
                        MAX(CASE WHEN meta_key = 'booking_status' THEN meta_value ELSE '' END) AS booking_status,
                        MAX(CASE WHEN meta_key = 'Number of persons' THEN meta_value ELSE 0 END) AS participant_count,
                        MAX(CASE WHEN meta_key = 'Assets' THEN meta_value ELSE '' END) AS asset_id,
                        MAX(CASE WHEN meta_key = 'person_as_booking' THEN meta_value ELSE '' END) AS person_as_booking,
                        MAX(CASE WHEN meta_key = '_phive_booking_product_interval_details' THEN (SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -1), '\"', 1)) ELSE '' END) AS interval_format,
                        MAX(CASE WHEN meta_key = '_phive_booking_product_interval_details' THEN (SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -3), '\"', 1)) ELSE '' END) AS interval_number,
                        MAX(CASE WHEN meta_key = 'buffer_before_id' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -1), '\";', 1) ELSE '' END) AS buffer_before_id,
                        MAX(CASE WHEN meta_key = 'buffer_after_id' THEN SUBSTRING_INDEX(SUBSTRING_INDEX(meta_value, ':\"', -1), '\";', 1) Else '' END) AS buffer_after_id
                        FROM {$wpdb->prefix}woocommerce_order_itemmeta
                        GROUP BY order_item_id
                    ) AS oimeta ON oimeta.order_item_id = oitems.order_item_id
                    INNER JOIN {$wpdb->prefix}term_relationships AS tr ON tr.object_id = oimeta.product_id
                    INNER JOIN {$wpdb->prefix}term_taxonomy AS tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                    INNER JOIN {$wpdb->prefix}terms AS t ON t.term_id = tt.term_id
                    LEFT JOIN
                    (
                        SELECT {$wpdb->prefix}posts.ID,
                        MAX(CASE WHEN {$wpdb->prefix}postmeta.meta_key = 'Buffer_after_To' THEN {$wpdb->prefix}postmeta.meta_value ELSE '' END) AS buffer_after_to,
                        MAX(CASE WHEN {$wpdb->prefix}postmeta.meta_key = 'Buffer_after_From' THEN {$wpdb->prefix}postmeta.meta_value ELSE '' END) AS buffer_after_from,
                        MAX(CASE WHEN {$wpdb->prefix}postmeta.meta_key = 'buffer_asset_id' THEN {$wpdb->prefix}postmeta.meta_value ELSE '' END) AS buffer_asset_id
                        FROM {$wpdb->prefix}posts
                        INNER JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}posts.ID = {$wpdb->prefix}postmeta.post_id
                        GROUP BY {$wpdb->prefix}posts.ID
                    ) AS wposts ON wposts.ID = oimeta.buffer_after_id
                    WHERE t.slug = 'phive_booking' and tt.taxonomy = 'product_type'
                    ORDER BY `oimeta`.`book_to` DESC limit 10";

            $data = $wpdb->get_results( $query, OBJECT );
            if(empty($data)){
                $this->migration['order_ids'] = $this->migration['order_ids_left'] = array();
                $this->migration['fetched_data'] = $this->migration['started'] = $this->migration['completed'] = $this->migration['migration_consent'] = 'yes';
                update_option($this->option_name, $this->migration);
                update_option('ph_migration_plugins_updated_v3_0_0', 'yes');
                update_option('ph_migration_env_set_v3_0_0', 'yes');
                update_option('ph_migration_final_consent_v3_0_0', 'yes');
                update_option('ph_migration_new_site_v3_0_0', 'yes');
                return true;
            }
            else{
                return false;
            }
        }

        public function ph_bookings_insert_data_in_availability_table_when_order_created_from_migration($order, $order_item_id='', $ph_booking_order='')
        {
            $data['order_id'] 					= $order->get_id();
            $data['woocommerce_order_status'] 	= $order->get_status();
            $order_items 						= $order->get_items();
            foreach($order_items as $item_id => $item)
            {
                // When new order item added/modified to existing booking
                if($ph_booking_order == 'existing')
                {
                    if($order_item_id != $item_id)
                    {
                        continue;
                    }
                }

                $data['product_id']		 = $item->get_product_id();
                $product 				 = wc_get_product($data['product_id']);

                // Skip the product if it is deleted
                if (!$product instanceof WC_Product) {
                    continue;
                }

                if($product->get_type() != 'phive_booking')
                {
                    continue;
                }
                $data['order_item_id'] 	 	= $item_id;
                $data['booking_type']  	 	= 'booked';
                
                // Product Settings
                $settings 				 	= Ph_Booking_Manage_Availability_Data::ph_get_product_settings($data['product_id']);
                // interval details
                $data['interval']		 	= $settings['interval'];
                $data['interval_format'] 	= $settings['interval_period'];
                $data['charge_per_night']	= $settings['charge_per_night'];

                // Booking Dates
                $booked_from_date			= ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'From', 1));
                $booked_to_date  			= ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'To', 1));
                $booked_to_date				= $booked_to_date ? $booked_to_date : $booked_from_date;
                $data['booking_status']  	= ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'booking_status', 1));
                
                // Participants 
                $data['number_of_persons']  = wc_get_order_item_meta($item_id, 'Number of persons', 1);
                $data['number_of_persons']	= $data['number_of_persons'] ? $data['number_of_persons'] : 0;
                $data['person_as_booking']  = ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'person_as_booking', 1));
                $data['person_as_booking']	= $data['person_as_booking'] ? $data['person_as_booking'] : 'no';

                // Participant Group Addon
                $phive_booked_persons = maybe_unserialize(wc_get_order_item_meta($item_id, 'ph_bookings_participant_booking_data', 1));
                if(is_array($phive_booked_persons) && !empty($phive_booked_persons))
                {
                    $participant_booking_data 	= '';
                    // Looping through the rule and assign the corresponding rule value given by customer
                    foreach ($phive_booked_persons as $phive_booked_person)
                    {
                        // "Participant(s)":"1";"Family":"2";
                        $participant_booking_data .= '"'.$phive_booked_person['participant_label'].'":"'.$phive_booked_person['participant_count'].'";';
                    }
                    if ($participant_booking_data)
                    {
                        $data['participant_detail'] = $participant_booking_data;
                    }
                }
                else
                {
                    $persons_pricing_rules = get_post_meta($data['product_id'], "_phive_booking_persons_pricing_rules", 1);
                    if($persons_pricing_rules)
                    {
                        $participant_booking_data = '';
                        $participant_names = array();
                        foreach ($persons_pricing_rules as $key => $rule)
                        {
                            $rule['ph_booking_persons_rule_type'] = apply_filters( 'wpml_translate_single_string', $rule['ph_booking_persons_rule_type'], 'bookings-and-appointments-for-woocommerce', 'participant_name_'.$rule['ph_booking_persons_rule_type'] );
                            $participant_names[] = $rule['ph_booking_persons_rule_type'];
                        }

                        if($participant_names)
                        {
                            foreach($participant_names as $participant_name)
                            {
                                $participant_count = wc_get_order_item_meta($item_id, $participant_name, 1);
                                if(is_numeric($participant_count))
                                {
                                    $participant_booking_data .= '"'.$participant_name.'":"'.$participant_count.'";';
                                }
                            }

                            if ($participant_booking_data)
                            {
                                $data['participant_detail'] = $participant_booking_data;
                            }
                        }
                    }
                }


                // Resources - Resource quantity addon.
                $phive_booked_resources = maybe_unserialize(wc_get_order_item_meta($item_id, 'ph_bookings_resources_booking_data', 1));
                if(is_array($phive_booked_resources) && !empty($phive_booked_resources))
                {
                    $resources_booking_data 	= '';
                    // Looping through the rule and assign the corresponding rule value given by customer
                    foreach ($phive_booked_resources as $phive_booked_resource)
                    {
                        $resource_count 		= apply_filters('ph_modify_resource_count_after_order_placed', 1, $item_id, $order, $settings, $phive_booked_resource['resource_label']);
                        $resources_booking_data .= '"'.$phive_booked_resource['resource_label'].'":"'.$resource_count.'";';
                    }
                    if ($resources_booking_data)
                    {
                        $data['resource_detail'] = $resources_booking_data;
                    }
                }
                else
                {
                    $resources_pricing_rules = get_post_meta($data['product_id'], "_phive_booking_resources_pricing_rules", 1);
                    
                    if($resources_pricing_rules)
                    {
                        $resources_booking_data = '';
                        $resource_names = array();
                        foreach ($resources_pricing_rules as $key => $rule)
                        {
                            $rule['ph_booking_resources_name'] = apply_filters( 'wpml_translate_single_string', $rule['ph_booking_resources_name'], 'bookings-and-appointments-for-woocommerce', 'resource_name_'.$rule['ph_booking_resources_name'] );
                            $resource_names[] = $rule['ph_booking_resources_name'];
                        }

                        if($resource_names)
                        {
                            foreach($resource_names as $resource_name)
                            {
                                $resource = wc_get_order_item_meta($item_id, $resource_name, 1);
                                if($resource == 'yes')
                                {
                                    $resource_count 		= apply_filters('ph_modify_resource_count_after_order_placed', 1, $item_id, $order, $settings, $resource_name);
                                    $resources_booking_data .= '"'.$resource_name.'":"'.$resource_count.'";';
                                }
                            }

                            if ($resources_booking_data)
                            {
                                $data['resource_detail'] = $resources_booking_data;
                            }
                        }
                    }
                }
                
                // Asset 
                $data['asset_id']  			= ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'Assets', 1));
                $data['asset_id']			= $data['asset_id'] ? $data['asset_id'] : NULL;
                
                // Buffer
                $buffer_before_id  			= ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'buffer_before_id', 1));
                $buffer_after_id  			= ph_maybe_unserialize(wc_get_order_item_meta($item_id, 'buffer_after_id', 1));
                $buffer_from_date			= $buffer_before_id ? get_post_meta($buffer_before_id, 'Buffer_before_From', 1) : $booked_from_date;
                $buffer_from_date			= $buffer_from_date ? $buffer_from_date : $booked_from_date;
                $buffer_to_date				= $buffer_after_id ? get_post_meta($buffer_after_id, 'Buffer_after_To', 1) : $booked_to_date;
                $buffer_to_date				= $buffer_to_date ? $buffer_to_date : $booked_to_date;
                
                Ph_Booking_Manage_Availability_Data::ph_bookings_insert_data_in_availability_table($data, $buffer_from_date, $buffer_to_date, $settings);
            }
        }

	} new Phive_Bookings_Migrate_Data();
}